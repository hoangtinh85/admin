<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Lấy danh sách phân công công việc
if ($_SESSION['role'] === 'employee') {
    $employeeId = $_SESSION['employee_id'] ?? 0;
    if (!$employeeId) {
        header('Location: ../dashboard.php');
        exit();
    }
    
    $stmt = $pdo->prepare("SELECT s.*, e.full_name as employee_name, u.username as created_by_name
                          FROM schedules s
                          JOIN employees e ON s.employee_id = e.id
                          JOIN users u ON s.created_by = u.id
                          WHERE s.employee_id = ?
                          ORDER BY s.start_date DESC");
    $stmt->execute([$employeeId]);
} else {
    $stmt = $pdo->query("SELECT s.*, e.full_name as employee_name, u.username as created_by_name
                        FROM schedules s
                        JOIN employees e ON s.employee_id = e.id
                        JOIN users u ON s.created_by = u.id
                        ORDER BY s.start_date DESC");
}

$schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Phân công công việc</h5>
            <?php if (has_permission('create_schedule')): ?>
            <a href="manage.php" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Thêm phân công
            </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="schedulesTable" class="table table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nhân viên</th>
                        <th>Tiêu đề</th>
                        <th>Bắt đầu</th>
                        <th>Kết thúc</th>
                        <th>Trạng thái</th>
                        <th>Người tạo</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($schedules as $index => $schedule): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($schedule['employee_name']) ?></td>
                        <td><?= htmlspecialchars($schedule['title']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($schedule['start_date'])) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($schedule['end_date'])) ?></td>
                        <td>
                            <?php 
                            $statusClass = [
                                'pending' => 'warning',
                                'in_progress' => 'info',
                                'completed' => 'success',
                                'cancelled' => 'danger'
                            ];
                            ?>
                            <span class="badge bg-<?= $statusClass[$schedule['status']] ?>">
                                <?= $schedule['status'] === 'pending' ? 'Chờ thực hiện' : 
                                   ($schedule['status'] === 'in_progress' ? 'Đang thực hiện' : 
                                   ($schedule['status'] === 'completed' ? 'Hoàn thành' : 'Đã hủy')) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($schedule['created_by_name']) ?></td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-info view-schedule" 
                                        data-id="<?= $schedule['id'] ?>">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <?php if (has_permission('edit_schedule')): ?>
                                <a href="manage.php?id=<?= $schedule['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (has_permission('delete_schedule')): ?>
                                <button class="btn btn-sm btn-danger delete-schedule" 
                                        data-id="<?= $schedule['id'] ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- View Schedule Modal -->
<div class="modal fade" id="viewScheduleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chi tiết phân công</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewScheduleModalBody">
                <!-- Nội dung sẽ được load bằng AJAX -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteScheduleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Xác nhận xóa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Bạn có chắc chắn muốn xóa phân công này?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteSchedule">Xóa</button>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>