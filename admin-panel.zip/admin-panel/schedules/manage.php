<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Kiểm tra quyền
if (!has_permission('create_schedule') && !has_permission('edit_schedule')) {
    header('Location: ../dashboard.php');
    exit();
}

$schedule = [
    'id' => 0,
    'employee_id' => 0,
    'title' => '',
    'description' => '',
    'start_date' => date('Y-m-d H:i'),
    'end_date' => date('Y-m-d H:i', strtotime('+1 hour')),
    'status' => 'pending'
];

// Nếu là chỉnh sửa, lấy thông tin phân công
if (isset($_GET['id'])) {
    $scheduleId = $_GET['id'];
    
    $stmt = $pdo->prepare("SELECT * FROM schedules WHERE id = ?");
    $stmt->execute([$scheduleId]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($data) {
        $schedule = $data;
    } else {
        header('Location: index.php');
        exit();
    }
}

// Lấy danh sách nhân viên
$stmt = $pdo->query("SELECT e.id, e.full_name 
                     FROM employees e
                     JOIN users u ON e.user_id = u.id
                     WHERE u.status = 1
                     ORDER BY e.full_name");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title"><?= $schedule['id'] ? 'Chỉnh sửa' : 'Thêm mới' ?> phân công</h5>
    </div>
    <div class="card-body">
        <form id="scheduleForm">
            <input type="hidden" name="schedule_id" value="<?= $schedule['id'] ?>">
            <input type="hidden" name="created_by" value="<?= $_SESSION['user_id'] ?>">
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="employee_id" class="form-label">Nhân viên *</label>
                        <select class="form-select" id="employee_id" name="employee_id" required>
                            <option value="">Chọn nhân viên</option>
                            <?php foreach ($employees as $employee): ?>
                            <option value="<?= $employee['id'] ?>" 
                                <?= $employee['id'] == $schedule['employee_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($employee['full_name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="status" class="form-label">Trạng thái *</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending" <?= $schedule['status'] === 'pending' ? 'selected' : '' ?>>Chờ thực hiện</option>
                            <option value="in_progress" <?= $schedule['status'] === 'in_progress' ? 'selected' : '' ?>>Đang thực hiện</option>
                            <option value="completed" <?= $schedule['status'] === 'completed' ? 'selected' : '' ?>>Hoàn thành</option>
                            <option value="cancelled" <?= $schedule['status'] === 'cancelled' ? 'selected' : '' ?>>Đã hủy</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="title" class="form-label">Tiêu đề *</label>
                <input type="text" class="form-control" id="title" name="title" 
                       value="<?= htmlspecialchars($schedule['title']) ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Mô tả</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($schedule['description']) ?></textarea>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="start_date" class="form-label">Thời gian bắt đầu *</label>
                        <input type="datetime-local" class="form-control" id="start_date" name="start_date" 
                               value="<?= date('Y-m-d\TH:i', strtotime($schedule['start_date'])) ?>" required>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="end_date" class="form-label">Thời gian kết thúc *</label>
                        <input type="datetime-local" class="form-control" id="end_date" name="end_date" 
                               value="<?= date('Y-m-d\TH:i', strtotime($schedule['end_date'])) ?>" required>
                    </div>
                </div>
            </div>
            
            <div class="text-end mt-4">
                <button type="button" class="btn btn-secondary" onclick="window.history.back()">Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu phân công</button>
            </div>
        </form>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>