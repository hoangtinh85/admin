<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Chỉ admin mới được quản lý người dùng
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../dashboard.php');
    exit();
}

$user = [
    'id' => 0,
    'username' => '',
    'email' => '',
    'role' => 'employee',
    'status' => 1
];

// Nếu là chỉnh sửa, lấy thông tin người dùng
if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($data) {
        $user = $data;
    } else {
        header('Location: index.php');
        exit();
    }
}

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title"><?= $user['id'] ? 'Chỉnh sửa' : 'Thêm mới' ?> người dùng</h5>
    </div>
    <div class="card-body">
        <form id="userForm">
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="username" class="form-label">Tên đăng nhập *</label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?= htmlspecialchars($user['username']) ?>" required
                               <?= $user['id'] ? 'readonly' : '' ?>>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                </div>
            </div>
            
            <?php if (!$user['id']): ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="password" class="form-label">Mật khẩu *</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Xác nhận mật khẩu *</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="role" class="form-label">Vai trò *</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="employee" <?= $user['role'] === 'employee' ? 'selected' : '' ?>>Nhân viên</option>
                            <option value="manager" <?= $user['role'] === 'manager' ? 'selected' : '' ?>>Quản lý</option>
                            <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Quản trị viên</option>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="status" class="form-label">Trạng thái *</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="1" <?= $user['status'] ? 'selected' : '' ?>>Hoạt động</option>
                            <option value="0" <?= !$user['status'] ? 'selected' : '' ?>>Vô hiệu hóa</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="text-end mt-4">
                <button type="button" class="btn btn-secondary" onclick="window.history.back()">Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu thông tin</button>
            </div>
        </form>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>