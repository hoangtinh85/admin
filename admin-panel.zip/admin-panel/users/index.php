<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Chỉ admin mới được quản lý người dùng
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../dashboard.php');
    exit();
}

$stmt = $pdo->query("SELECT u.*, e.full_name 
                     FROM users u
                     LEFT JOIN employees e ON u.id = e.user_id
                     ORDER BY u.id DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Quản lý người dùng</h5>
            <a href="manage.php" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Thêm người dùng
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="usersTable" class="table table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tên đăng nhập</th>
                        <th>Email</th>
                        <th>Vai trò</th>
                        <th>Nhân viên</th>
                        <th>Trạng thái</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $index => $user): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td>
                            <?= $user['role'] === 'admin' ? 'Quản trị viên' : 
                               ($user['role'] === 'manager' ? 'Quản lý' : 'Nhân viên') ?>
                        </td>
                        <td><?= $user['full_name'] ? htmlspecialchars($user['full_name']) : '---' ?></td>
                        <td>
                            <span class="badge bg-<?= $user['status'] ? 'success' : 'danger' ?>">
                                <?= $user['status'] ? 'Hoạt động' : 'Vô hiệu' ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <a href="manage.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-sm btn-danger delete-user" data-id="<?= $user['id'] ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Xác nhận xóa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Bạn có chắc chắn muốn xóa người dùng này? Hành động này sẽ xóa cả thông tin nhân viên liên quan.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteUser">Xóa</button>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>