<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Kiểm tra quyền
if (!has_permission('create_employee') && !has_permission('edit_employee')) {
    header('Location: ../dashboard.php');
    exit();
}

$employee = [
    'id' => 0,
    'user_id' => 0,
    'full_name' => '',
    'gender' => 'male',
    'birth_date' => '',
    'address' => '',
    'phone' => '',
    'department' => '',
    'position' => '',
    'salary' => '',
    'hire_date' => date('Y-m-d'),
    'photo' => ''
];

$user = [
    'id' => 0,
    'username' => '',
    'email' => '',
    'role' => 'employee',
    'status' => 1
];

// Nếu là chỉnh sửa, lấy thông tin nhân viên
if (isset($_GET['id']) {
    $employeeId = $_GET['id'];
    
    $stmt = $pdo->prepare("SELECT e.*, u.username, u.email, u.role, u.status 
                          FROM employees e 
                          JOIN users u ON e.user_id = u.id 
                          WHERE e.id = ?");
    $stmt->execute([$employeeId]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($data) {
        $employee = $data;
        $user = [
            'id' => $data['user_id'],
            'username' => $data['username'],
            'email' => $data['email'],
            'role' => $data['role'],
            'status' => $data['status']
        ];
    } else {
        header('Location: index.php');
        exit();
    }
}

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title"><?= $employee['id'] ? 'Chỉnh sửa' : 'Thêm mới' ?> nhân viên</h5>
    </div>
    <div class="card-body">
        <form id="employeeForm" enctype="multipart/form-data">
            <input type="hidden" name="employee_id" value="<?= $employee['id'] ?>">
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            
            <div class="row">
                <div class="col-md-6">
                    <h6 class="mb-3">Thông tin tài khoản</h6>
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Tên đăng nhập *</label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?= htmlspecialchars($user['username']) ?>" required
                               <?= $user['id'] ? 'readonly' : '' ?>>
                    </div>
                    
                    <?php if (!$user['id']): ?>
                    <div class="mb-3">
                        <label for="password" class="form-label">Mật khẩu *</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="role" class="form-label">Vai trò *</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="employee" <?= $user['role'] === 'employee' ? 'selected' : '' ?>>Nhân viên</option>
                            <option value="manager" <?= $user['role'] === 'manager' ? 'selected' : '' ?>>Quản lý</option>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Quản trị viên</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="user_status" class="form-label">Trạng thái tài khoản *</label>
                        <select class="form-select" id="user_status" name="user_status" required>
                            <option value="1" <?= $user['status'] ? 'selected' : '' ?>>Hoạt động</option>
                            <option value="0" <?= !$user['status'] ? 'selected' : '' ?>>Vô hiệu hóa</option>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <h6 class="mb-3">Thông tin cá nhân</h6>
                    
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Họ và tên *</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" 
                               value="<?= htmlspecialchars($employee['full_name']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="gender" class="form-label">Giới tính *</label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="male" <?= $employee['gender'] === 'male' ? 'selected' : '' ?>>Nam</option>
                            <option value="female" <?= $employee['gender'] === 'female' ? 'selected' : '' ?>>Nữ</option>
                            <option value="other" <?= $employee['gender'] === 'other' ? 'selected' : '' ?>>Khác</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="birth_date" class="form-label">Ngày sinh *</label>
                        <input type="date" class="form-control" id="birth_date" name="birth_date" 
                               value="<?= $employee['birth_date'] ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Số điện thoại *</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               value="<?= htmlspecialchars($employee['phone']) ?>" required>
                    </div>
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="address" class="form-label">Địa chỉ *</label>
                        <textarea class="form-control" id="address" name="address" rows="2" required><?= htmlspecialchars($employee['address']) ?></textarea>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="photo" class="form-label">Ảnh đại diện</label>
                        <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                        <small class="text-muted">Chỉ chấp nhận file ảnh (JPEG, PNG), tối đa 2MB</small>
                    </div>
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="department" class="form-label">Phòng ban *</label>
                        <input type="text" class="form-control" id="department" name="department" 
                               value="<?= htmlspecialchars($employee['department']) ?>" required>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="position" class="form-label">Chức vụ *</label>
                        <input type="text" class="form-control" id="position" name="position" 
                               value="<?= htmlspecialchars($employee['position']) ?>" required>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="salary" class="form-label">Lương cơ bản *</label>
                        <input type="number" class="form-control" id="salary" name="salary" 
                               value="<?= $employee['salary'] ?>" step="0.01" required>
                    </div>
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="hire_date" class="form-label">Ngày vào làm *</label>
                        <input type="date" class="form-control" id="hire_date" name="hire_date" 
                               value="<?= $employee['hire_date'] ?>" required>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <?php if ($employee['photo']): ?>
                    <div class="mb-3">
                        <label class="form-label">Ảnh hiện tại</label>
                        <div>
                            <img src="../../assets/img/uploads/employees/<?= $employee['photo'] ?>" 
                                 class="img-thumbnail" width="100" alt="Ảnh nhân viên">
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="text-end mt-4">
                <button type="button" class="btn btn-secondary" onclick="window.history.back()">Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu thông tin</button>
            </div>
        </form>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>