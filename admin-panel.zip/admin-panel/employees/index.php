<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Chỉ admin và manager mới được xem danh sách nhân viên
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    header('Location: ../dashboard.php');
    exit();
}

$stmt = $pdo->query("SELECT e.*, u.username, u.email, u.status as user_status 
                     FROM employees e 
                     JOIN users u ON e.user_id = u.id");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Quản lý nhân viên</h5>
            <?php if (has_permission('create_employee')): ?>
            <a href="manage.php" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Thêm nhân viên
            </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="employeesTable" class="table table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Ảnh</th>
                        <th>Họ tên</th>
                        <th>Giới tính</th>
                        <th>Phòng ban</th>
                        <th>Chức vụ</th>
                        <th>Trạng thái</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employees as $index => $employee): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td>
                            <img src="<?= $employee['photo'] ? '../../assets/img/uploads/employees/'.$employee['photo'] : '../../assets/img/user.png' ?>" 
                                 class="rounded-circle" width="40" height="40" alt="Ảnh nhân viên">
                        </td>
                        <td><?= htmlspecialchars($employee['full_name']) ?></td>
                        <td>
                            <?= $employee['gender'] === 'male' ? 'Nam' : 
                                ($employee['gender'] === 'female' ? 'Nữ' : 'Khác') ?>
                        </td>
                        <td><?= htmlspecialchars($employee['department']) ?></td>
                        <td><?= htmlspecialchars($employee['position']) ?></td>
                        <td>
                            <span class="badge bg-<?= $employee['user_status'] ? 'success' : 'danger' ?>">
                                <?= $employee['user_status'] ? 'Hoạt động' : 'Vô hiệu' ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <a href="view.php?id=<?= $employee['id'] ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if (has_permission('edit_employee')): ?>
                                <a href="manage.php?id=<?= $employee['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (has_permission('delete_employee')): ?>
                                <button class="btn btn-sm btn-danger delete-employee" data-id="<?= $employee['id'] ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Xác nhận xóa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Bạn có chắc chắn muốn xóa nhân viên này? Hành động này không thể hoàn tác.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Xóa</button>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>