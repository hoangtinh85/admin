<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$employeeId = $_GET['id'];

$stmt = $pdo->prepare("SELECT e.*, u.username, u.email, u.role, u.status as user_status 
                      FROM employees e 
                      JOIN users u ON e.user_id = u.id 
                      WHERE e.id = ?");
$stmt->execute([$employeeId]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$employee) {
    header('Location: index.php');
    exit();
}

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Thông tin nhân viên: <?= htmlspecialchars($employee['full_name']) ?></h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4 text-center">
                <img src="<?= $employee['photo'] ? '../../assets/img/uploads/employees/'.$employee['photo'] : '../../assets/img/user.png' ?>" 
                     class="employee-photo" alt="Ảnh nhân viên">
            </div>
            <div class="col-md-8">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Tên đăng nhập:</strong> <?= htmlspecialchars($employee['username']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Email:</strong> <?= htmlspecialchars($employee['email']) ?></p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Vai trò:</strong> 
                            <?= $employee['role'] === 'admin' ? 'Quản trị viên' : 
                               ($employee['role'] === 'manager' ? 'Quản lý' : 'Nhân viên') ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Trạng thái tài khoản:</strong> 
                            <span class="badge bg-<?= $employee['user_status'] ? 'success' : 'danger' ?>">
                                <?= $employee['user_status'] ? 'Hoạt động' : 'Vô hiệu' ?>
                            </span>
                        </p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Giới tính:</strong> 
                            <?= $employee['gender'] === 'male' ? 'Nam' : 
                               ($employee['gender'] === 'female' ? 'Nữ' : 'Khác') ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Ngày sinh:</strong> <?= date('d/m/Y', strtotime($employee['birth_date'])) ?></p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Số điện thoại:</strong> <?= htmlspecialchars($employee['phone']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Ngày vào làm:</strong> <?= date('d/m/Y', strtotime($employee['hire_date'])) ?></p>
                    </div>
                </div>
                <div class="mb-3">
                    <p><strong>Địa chỉ:</strong> <?= htmlspecialchars($employee['address']) ?></p>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Phòng ban:</strong> <?= htmlspecialchars($employee['department']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Chức vụ:</strong> <?= htmlspecialchars($employee['position']) ?></p>
                    </div>
                </div>
                <div class="mb-3">
                    <p><strong>Lương cơ bản:</strong> <?= number_format($employee['salary'], 0, ',', '.') ?> VNĐ</p>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer text-end">
        <a href="index.php" class="btn btn-secondary">Quay lại</a>
        <?php if (has_permission('edit_employee')): ?>
        <a href="manage.php?id=<?= $employee['id'] ?>" class="btn btn-primary">Chỉnh sửa</a>
        <?php endif; ?>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>