<?php
require_once 'database.php';

// Hàm chuyển hướng
function redirect($url) {
    header("Location: $url");
    exit();
}

// Hàm kiểm tra đăng nhập
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Hàm yêu cầu đăng nhập
function require_login() {
    if (!is_logged_in()) {
        redirect('auth/login.php');
    }
}

// Hàm kiểm tra vai trò
function require_role($role) {
    require_login();
    if (!in_array($_SESSION['role'], (array)$role)) {
        redirect('dashboard.php');
    }
}

// Hàm kiểm tra quyền
function has_permission($permission) {
    global $pdo;
    
    if (!is_logged_in()) return false;
    if ($_SESSION['role'] === 'admin') return true;
    
    $stmt = $pdo->prepare("SELECT 1 FROM permissions p
                          JOIN role_permissions rp ON p.id = rp.permission_id
                          WHERE rp.role = ? AND p.name = ?");
    $stmt->execute([$_SESSION['role'], $permission]);
    
    return $stmt->fetch() !== false;
}

// Hàm lấy thông tin nhân viên
function get_employee($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

// Hàm upload ảnh
function upload_image($file, $target_dir) {
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $target_file = $target_dir . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $new_filename = uniqid() . '.' . $imageFileType;
    $new_target = $target_dir . $new_filename;
    
    // Kiểm tra file ảnh
    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        throw new Exception("File không phải là ảnh");
    }
    
    // Kiểm tra kích thước
    if ($file["size"] > 5000000) {
        throw new Exception("File quá lớn (>5MB)");
    }
    
    // Kiểm tra định dạng
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        throw new Exception("Chỉ chấp nhận JPG, JPEG, PNG & GIF");
    }
    
    if (move_uploaded_file($file["tmp_name"], $new_target)) {
        return $new_filename;
    } else {
        throw new Exception("Lỗi khi upload file");
    }
}
?>