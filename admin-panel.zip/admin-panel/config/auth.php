<?php
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /auth/login.php');
        exit();
    }
}

function require_role($role) {
    require_login();
    if ($_SESSION['role'] !== $role) {
        header('Location: ../dashboard.php');
        exit();
    }
}

function has_permission($permission_name) {
    global $pdo;
    
    if (!is_logged_in()) return false;
    if ($_SESSION['role'] === 'admin') return true;
    
    $stmt = $pdo->prepare("SELECT p.id FROM permissions p
                          JOIN role_permissions rp ON p.id = rp.permission_id
                          WHERE rp.role = ? AND p.name = ?");
    $stmt->execute([$_SESSION['role'], $permission_name]);
    
    return $stmt->fetch() !== false;
}
?>