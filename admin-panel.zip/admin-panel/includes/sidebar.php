<div class="sidebar-wrapper">
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="text-center text-white py-3">Hotel Management</h4>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-item">
                <a href="dashboard.php" class="menu-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <li class="menu-item has-submenu">
                <a href="#" class="menu-link">
                    <i class="fas fa-hotel"></i>
                    <span>Quản lý phòng</span>
                    <i class="fas fa-angle-down dropdown-icon"></i>
                </a>
                <ul class="submenu">
                    <li><a href="../rooms/index.php"><i class="fas fa-list"></i> Danh sách phòng</a></li>
                    <li><a href="../rooms/manage.php"><i class="fas fa-plus-circle"></i> Thêm phòng</a></li>
                </ul>
            </li>
            
            <li class="menu-item has-submenu">
                <a href="#" class="menu-link">
                    <i class="fas fa-users"></i>
                    <span>Quản lý nhân sự</span>
                    <i class="fas fa-angle-down dropdown-icon"></i>
                </a>
                <ul class="submenu">
                    <li><a href="../employees/index.php"><i class="fas fa-list"></i> Nhân viên</a></li>
                    <li><a href="../attendance/index.php"><i class="fas fa-clipboard-check"></i> Chấm công</a></li>
                    <li><a href="../schedules/index.php"><i class="fas fa-calendar-alt"></i> Phân công</a></li>
                </ul>
            </li>
            
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <li class="menu-item has-submenu">
                <a href="#" class="menu-link">
                    <i class="fas fa-user-cog"></i>
                    <span>Hệ thống</span>
                    <i class="fas fa-angle-down dropdown-icon"></i>
                </a>
                <ul class="submenu">
                    <li><a href="../users/index.php"><i class="fas fa-users-cog"></i> Người dùng</a></li>
                    <li><a href="../permissions/index.php"><i class="fas fa-key"></i> Phân quyền</a></li>
                </ul>
            </li>
            <?php endif; ?>
        </ul>
        
        <div class="sidebar-footer">
            <div class="user-info">
                <img src="../assets/img/user.png" alt="User" class="user-avatar">
                <div class="user-details">
                    <span class="user-name"><?= $_SESSION['full_name'] ?? 'Admin' ?></span>
                    <span class="user-role">
                        <?= $_SESSION['role'] === 'admin' ? 'Quản trị viên' : 
                           ($_SESSION['role'] === 'manager' ? 'Quản lý' : 'Nhân viên') ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>