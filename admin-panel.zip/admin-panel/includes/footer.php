                </div> <!-- Kết thúc container-fluid -->
            </main>
        </div> <!-- Kết thúc main -->
    </div> <!-- Kết thúc wrapper -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/responsive.bootstrap5.min.js"></script>
    
    <!-- Custom JS -->
    <script src="../assets/js/script.js"></script>
    
    <script>
        // Toggle sidebar
        $('#sidebarToggle').click(function() {
            $('.sidebar-wrapper').toggleClass('collapsed');
            $('.main').toggleClass('expanded');
        });
        
        // Toggle submenu
        $('.has-submenu > a').click(function(e) {
            e.preventDefault();
            $(this).parent().toggleClass('open');
            $(this).find('.dropdown-icon').toggleClass('fa-rotate-180');
        });
        
        // Initialize DataTables
        $(document).ready(function() {
            $('.data-table').DataTable({
                responsive: true,
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/vi.json'
                }
            });
        });
    </script>
</body>
</html>