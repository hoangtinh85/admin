<?php
session_start(); 
require_once 'config/database.php';
require_once 'config/auth.php';
require_login();

// Lấy thống kê
$stats = [];
$stmt = $pdo->query("SELECT COUNT(*) as total_rooms FROM rooms WHERE status = 1 AND removed = 0");
$stats['available_rooms'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as total_employees FROM employees e JOIN users u ON e.user_id = u.id WHERE u.status = 1");
$stats['total_employees'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as today_checkins FROM bookings WHERE DATE(check_in_date) = CURDATE()");
$stats['today_checkins'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as today_checkouts FROM bookings WHERE DATE(check_out_date) = CURDATE()");
$stats['today_checkouts'] = $stmt->fetchColumn();

require_once 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Phòng trống</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $stats['available_rooms'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-bed fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Nhân viên</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $stats['total_employees'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Check-in hôm nay</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $stats['today_checkins'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-sign-in-alt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Check-out hôm nay</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $stats['today_checkouts'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-sign-out-alt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Lịch làm việc gần đây</h6>
                </div>
                <div class="card-body">
                    <?php
                    $stmt = $pdo->prepare("SELECT s.title, s.start_date, s.end_date, e.full_name 
                                          FROM schedules s
                                          JOIN employees e ON s.employee_id = e.id
                                          WHERE s.start_date >= NOW()
                                          ORDER BY s.start_date ASC
                                          LIMIT 5");
                    $stmt->execute();
                    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (count($schedules) > 0): ?>
                        <div class="list-group">
                            <?php foreach ($schedules as $schedule): ?>
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?= htmlspecialchars($schedule['title']) ?></h6>
                                    <small><?= date('d/m', strtotime($schedule['start_date'])) ?></small>
                                </div>
                                <p class="mb-1">Nhân viên: <?= htmlspecialchars($schedule['full_name']) ?></p>
                                <small>Bắt đầu: <?= date('H:i', strtotime($schedule['start_date'])) ?></small>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-muted">Không có lịch làm việc sắp tới</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Hoạt động gần đây</h6>
                </div>
                <div class="card-body">
                    <div class="activity-feed">
                        <?php
                        // Giả lập dữ liệu hoạt động
                        $activities = [
                            ['icon' => 'fa-user-plus', 'color' => 'success', 'text' => 'Nhân viên mới đăng ký: Nguyễn Văn A', 'time' => '10 phút trước'],
                            ['icon' => 'fa-bed', 'color' => 'primary', 'text' => 'Phòng Deluxe đã được đặt', 'time' => '30 phút trước'],
                            ['icon' => 'fa-sign-in-alt', 'color' => 'info', 'text' => 'Khách hàng check-in phòng 101', 'time' => '1 giờ trước'],
                            ['icon' => 'fa-cleaning', 'color' => 'warning', 'text' => 'Phòng 205 cần dọn dẹp', 'time' => '2 giờ trước'],
                            ['icon' => 'fa-comment', 'color' => 'secondary', 'text' => 'Bình luận mới từ khách hàng', 'time' => '3 giờ trước']
                        ];
                        
                        foreach ($activities as $activity): ?>
                        <div class="feed-item">
                            <div class="feed-icon bg-<?= $activity['color'] ?>">
                                <i class="fas <?= $activity['icon'] ?> text-white"></i>
                            </div>
                            <div class="feed-content">
                                <span class="feed-text"><?= $activity['text'] ?></span>
                                <small class="feed-time"><?= $activity['time'] ?></small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>