<?php
require_once 'config/database.php';

try {
    // Tạo bảng users
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `users` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `username` varchar(50) NOT NULL,
            `password` varchar(255) NOT NULL,
            `email` varchar(100) NOT NULL,
            `role` enum('admin','manager','employee') NOT NULL DEFAULT 'employee',
            `status` tinyint(1) NOT NULL DEFAULT 1,
            `removed` tinyint(1) NOT NULL DEFAULT 0,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            UNIQUE KEY `username` (`username`),
            UNIQUE KEY `email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng employees
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `employees` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `full_name` varchar(100) NOT NULL,
            `gender` enum('male','female','other') NOT NULL,
            `birth_date` date NOT NULL,
            `address` text NOT NULL,
            `phone` varchar(20) NOT NULL,
            `department` varchar(50) NOT NULL,
            `position` varchar(50) NOT NULL,
            `salary` decimal(10,2) NOT NULL,
            `hire_date` date NOT NULL,
            `photo` varchar(255) DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `user_id` (`user_id`),
            CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng attendance
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `attendance` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `employee_id` int(11) NOT NULL,
            `date` date NOT NULL,
            `check_in` time DEFAULT NULL,
            `check_out` time DEFAULT NULL,
            `status` enum('present','absent','late','leave') NOT NULL DEFAULT 'present',
            `notes` text DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `employee_id` (`employee_id`),
            CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng schedules
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `schedules` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `employee_id` int(11) NOT NULL,
            `title` varchar(100) NOT NULL,
            `description` text DEFAULT NULL,
            `start_date` datetime NOT NULL,
            `end_date` datetime NOT NULL,
            `status` enum('pending','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
            `created_by` int(11) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `employee_id` (`employee_id`),
            KEY `created_by` (`created_by`),
            CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
            CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng permissions
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `permissions` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(50) NOT NULL,
            `description` text DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `name` (`name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng role_permissions
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `role_permissions` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `role` enum('admin','manager','employee') NOT NULL,
            `permission_id` int(11) NOT NULL,
            PRIMARY KEY (`id`),
            KEY `permission_id` (`permission_id`),
            CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng rooms
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `rooms` (
            `id` int(11) NOT NULL,
            `languages_id` int(11) NOT NULL,
            `name` varchar(150) NOT NULL,
            `area` int(11) NOT NULL,
            `price` int(11) NOT NULL,
            `quantity` int(11) NOT NULL,
            `adult` int(11) NOT NULL,
            `children` int(11) NOT NULL,
            `description` text NOT NULL,
            `status` tinyint(4) NOT NULL DEFAULT 1,
            `removed` int(11) NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ");
    
    // Tạo bảng room_facilities
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `room_facilities` (
            `sr_no` int(11) NOT NULL,
            `room_id` int(11) NOT NULL,
            `facilities_id` int(11) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng room_features
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `room_features` (
            `sr_no` int(11) NOT NULL,
            `room_id` int(11) NOT NULL,
            `features_id` int(11) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng room_images
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `room_images` (
            `sr_no` int(11) NOT NULL,
            `room_id` int(11) NOT NULL,
            `image` varchar(150) NOT NULL,
            `thumb` tinyint(4) NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng facilities
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `facilities` (
            `id` int(11) NOT NULL,
            `icon` varchar(100) NOT NULL,
            `name` varchar(50) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng features
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `features` (
            `id` int(11) NOT NULL,
            `name` varchar(50) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    
    // Tạo bảng languages
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `languages` (
            `id` int(11) NOT NULL,
            `code` varchar(10) NOT NULL,
            `name` varchar(50) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    
    // Thêm dữ liệu mẫu
    // Tạo user admin mặc định
    $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `status`, `created_at`, `updated_at`) 
               VALUES (1, 'admin', '$hashedPassword', 'admin@example.com', 'admin', 1, NOW(), NOW())");
    
    // Thêm các quyền cơ bản
    $pdo->exec("INSERT INTO `permissions` (`id`, `name`, `description`) VALUES
               (1, 'user_manage', 'Quản lý người dùng'),
               (2, 'employee_manage', 'Quản lý nhân viên'),
               (3, 'attendance_manage', 'Quản lý chấm công'),
               (4, 'schedule_manage', 'Quản lý lịch làm việc'),
               (5, 'report_view', 'Xem báo cáo'),
               (6, 'room_manage', 'Quản lý phòng')");
    
    // Phân quyền cho admin
    $pdo->exec("INSERT INTO `role_permissions` (`id`, `role`, `permission_id`) VALUES
               (1, 'admin', 1),
               (2, 'admin', 2),
               (3, 'admin', 3),
               (4, 'admin', 4),
               (5, 'admin', 5),
               (6, 'admin', 6)");
    
    // Phân quyền cho manager
    $pdo->exec("INSERT INTO `role_permissions` (`id`, `role`, `permission_id`) VALUES
               (7, 'manager', 2),
               (8, 'manager', 3),
               (9, 'manager', 4),
               (10, 'manager', 5),
               (11, 'manager', 6)");
    
    // Phân quyền cho employee
    $pdo->exec("INSERT INTO `role_permissions` (`id`, `role`, `permission_id`) VALUES
               (12, 'employee', 5)");
    
    // Thêm ngôn ngữ mẫu
    $pdo->exec("INSERT INTO `languages` (`id`, `code`, `name`) VALUES
               (1, 'en', 'English'),
               (2, 'vi', 'Vietnamese')");
    
    // Thêm tiện ích mẫu
    $pdo->exec("INSERT INTO `facilities` (`id`, `icon`, `name`) VALUES
               (1, 'fas fa-wifi', 'WiFi'),
               (2, 'fas fa-tv', 'TV'),
               (3, 'fas fa-snowflake', 'Air Conditioning'),
               (4, 'fas fa-utensils', 'Breakfast'),
               (5, 'fas fa-swimming-pool', 'Swimming Pool')");
    
    // Thêm đặc điểm mẫu
    $pdo->exec("INSERT INTO `features` (`id`, `name`) VALUES
               (1, 'Sea View'),
               (2, 'Balcony'),
               (3, 'Garden View'),
               (4, 'City View'),
               (5, 'Mountain View')");
    
    echo "Database setup completed successfully!";
    
} catch (PDOException $e) {
    die("Database setup failed: " . $e->getMessage());
}