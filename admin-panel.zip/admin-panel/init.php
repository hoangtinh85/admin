<?php
// Khởi động session
session_start();

// Thiết lập múi giờ
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Đường dẫn gốc
define('BASE_PATH', realpath(dirname(__FILE__)));

// Autoload classes
spl_autoload_register(function ($class) {
    $file = BASE_PATH . '/includes/classes/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require $file;
    }
});

// Load config
require BASE_PATH . '/config/database.php';
require BASE_PATH . '/config/auth.php';
require BASE_PATH . '/config/functions.php';

// Xử lý lỗi
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>