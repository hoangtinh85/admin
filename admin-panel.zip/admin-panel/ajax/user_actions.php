<?php
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'save':
            // Xử lý lưu/thêm mới người dùng
            $userId = $_POST['user_id'] ?? 0;
            $data = [
                'username' => $_POST['username'],
                'email' => $_POST['email'],
                'role' => $_POST['role'],
                'status' => $_POST['status']
            ];
            
            // Kiểm tra mật khẩu nếu là thêm mới
            if (!$userId) {
                if ($_POST['password'] !== $_POST['confirm_password']) {
                    throw new Exception('Mật khẩu xác nhận không khớp');
                }
                
                $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
            }
            
            if ($userId) {
                // Cập nhật user
                $stmt = $pdo->prepare("UPDATE users SET 
                    email = :email, 
                    role = :role, 
                    status = :status 
                    WHERE id = :id");
                $data['id'] = $userId;
                $stmt->execute($data);
                
                $response['message'] = 'Cập nhật người dùng thành công';
            } else {
                // Thêm user mới
                $stmt = $pdo->prepare("INSERT INTO users 
                    (username, password, email, role, status) 
                    VALUES (:username, :password, :email, :role, :status)");
                $stmt->execute($data);
                $userId = $pdo->lastInsertId();
                
                $response['message'] = 'Thêm người dùng mới thành công';
            }
            
            $response['success'] = true;
            $response['user_id'] = $userId;
            break;
            
        case 'delete':
            // Xóa người dùng
            $userId = $_POST['user_id'];
            
            // Kiểm tra xem có phải là admin cuối cùng không
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin' AND id != ?");
            $stmt->execute([$userId]);
            $adminCount = $stmt->fetchColumn();
            
            if ($adminCount < 1) {
                throw new Exception('Không thể xóa admin cuối cùng');
            }
            
            // Xóa user (sẽ tự động xóa employee liên quan qua foreign key)
            $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$userId]);
            
            $response['success'] = true;
            $response['message'] = 'Xóa người dùng thành công';
            break;
            
        default:
            $response['message'] = 'Hành động không hợp lệ';
    }
} catch (PDOException $e) {
    $response['message'] = 'Lỗi cơ sở dữ liệu: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = 'Lỗi: ' . $e->getMessage();
}

echo json_encode($response);
?>