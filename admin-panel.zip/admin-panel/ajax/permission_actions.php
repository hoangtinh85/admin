<?php
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_permission':
            // Thêm quyền mới
            $name = $_POST['name'];
            $description = $_POST['description'] ?? '';
            $roles = $_POST['roles'] ?? [];
            
            // Kiểm tra quyền đã tồn tại chưa
            $stmt = $pdo->prepare("SELECT id FROM permissions WHERE name = ?");
            $stmt->execute([$name]);
            
            if ($stmt->fetch()) {
                throw new Exception('Quyền này đã tồn tại');
            }
            
            // Thêm quyền mới
            $stmt = $pdo->prepare("INSERT INTO permissions (name, description) VALUES (?, ?)");
            $stmt->execute([$name, $description]);
            $permissionId = $pdo->lastInsertId();
            
            // Thêm phân quyền cho các role
            if (!empty($roles)) {
                $stmt = $pdo->prepare("INSERT INTO role_permissions (role, permission_id) VALUES (?, ?)");
                foreach ($roles as $role) {
                    $stmt->execute([$role, $permissionId]);
                }
            }
            
            $response['success'] = true;
            $response['message'] = 'Thêm quyền mới thành công';
            $response['permission_id'] = $permissionId;
            break;
            
        case 'get_permission':
            // Lấy thông tin quyền để chỉnh sửa
            $permissionId = $_POST['permission_id'];
            
            // Lấy thông tin quyền
            $stmt = $pdo->prepare("SELECT * FROM permissions WHERE id = ?");
            $stmt->execute([$permissionId]);
            $permission = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($permission) {
                // Lấy các role có quyền này
                $stmt = $pdo->prepare("SELECT role FROM role_permissions WHERE permission_id = ?");
                $stmt->execute([$permissionId]);
                $roles = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                ob_start();
                ?>
                <form id="editPermissionForm">
                    <input type="hidden" name="permission_id" value="<?= $permission['id'] ?>">
                    <input type="hidden" name="action" value="update_permission">
                    
                    <div class="mb-3">
                        <label for="edit_permission_name" class="form-label">Tên quyền *</label>
                        <input type="text" class="form-control" id="edit_permission_name" 
                               name="name" value="<?= htmlspecialchars($permission['name']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_permission_description" class="form-label">Mô tả</label>
                        <textarea class="form-control" id="edit_permission_description" 
                                  name="description" rows="3"><?= htmlspecialchars($permission['description']) ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Áp dụng cho vai trò</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="roles[]" 
                                   value="admin" id="edit_role_admin" <?= in_array('admin', $roles) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="edit_role_admin">Quản trị viên</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="roles[]" 
                                   value="manager" id="edit_role_manager" <?= in_array('manager', $roles) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="edit_role_manager">Quản lý</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="roles[]" 
                                   value="employee" id="edit_role_employee" <?= in_array('employee', $roles) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="edit_role_employee">Nhân viên</label>
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                    </div>
                </form>
                <?php
                $response['html'] = ob_get_clean();
                $response['success'] = true;
            } else {
                $response['message'] = 'Không tìm thấy quyền';
            }
            break;
            
        case 'update_permission':
            // Cập nhật quyền
            $permissionId = $_POST['permission_id'];
            $name = $_POST['name'];
            $description = $_POST['description'] ?? '';
            $roles = $_POST['roles'] ?? [];
            
            // Cập nhật thông tin quyền
            $stmt = $pdo->prepare("UPDATE permissions SET 
                name = ?, 
                description = ? 
                WHERE id = ?");
            $stmt->execute([$name, $description, $permissionId]);
            
            // Xóa tất cả phân quyền cũ
            $pdo->prepare("DELETE FROM role_permissions WHERE permission_id = ?")->execute([$permissionId]);
            
            // Thêm phân quyền mới
            if (!empty($roles)) {
                $stmt = $pdo->prepare("INSERT INTO role_permissions (role, permission_id) VALUES (?, ?)");
                foreach ($roles as $role) {
                    $stmt->execute([$role, $permissionId]);
                }
            }
            
            $response['success'] = true;
            $response['message'] = 'Cập nhật quyền thành công';
            break;
            
        case 'delete_permission':
            // Xóa quyền
            $permissionId = $_POST['permission_id'];
            
            // Xóa phân quyền trước
            $pdo->prepare("DELETE FROM role_permissions WHERE permission_id = ?")->execute([$permissionId]);
            
            // Xóa quyền
            $pdo->prepare("DELETE FROM permissions WHERE id = ?")->execute([$permissionId]);
            
            $response['success'] = true;
            $response['message'] = 'Xóa quyền thành công';
            break;
            
        default:
            $response['message'] = 'Hành động không hợp lệ';
    }
} catch (PDOException $e) {
    $response['message'] = 'Lỗi cơ sở dữ liệu: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = 'Lỗi: ' . $e->getMessage();
}

echo json_encode($response);
?>