<?php
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'save':
            // Xử lý lưu/thêm mới nhân viên
            $employeeId = $_POST['employee_id'] ?? 0;
            $userId = $_POST['user_id'] ?? 0;
            
            // Dữ liệu user
            $userData = [
                'username' => $_POST['username'],
                'email' => $_POST['email'],
                'role' => $_POST['role'],
                'status' => $_POST['user_status']
            ];
            
            // Dữ liệu employee
            $employeeData = [
                'full_name' => $_POST['full_name'],
                'gender' => $_POST['gender'],
                'birth_date' => $_POST['birth_date'],
                'address' => $_POST['address'],
                'phone' => $_POST['phone'],
                'department' => $_POST['department'],
                'position' => $_POST['position'],
                'salary' => $_POST['salary'],
                'hire_date' => $_POST['hire_date']
            ];
            
            // Xử lý ảnh upload
            if (!empty($_FILES['photo']['name'])) {
                $uploadDir = '../assets/img/uploads/employees/';
                if (!file_exists($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $fileName = uniqid('emp_') . '.' . pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
                $filePath = $uploadDir . $fileName;
                
                if (move_uploaded_file($_FILES['photo']['tmp_name'], $filePath)) {
                    $employeeData['photo'] = $fileName;
                    
                    // Xóa ảnh cũ nếu có
                    if ($employeeId && !empty($_POST['old_photo'])) {
                        $oldFile = $uploadDir . $_POST['old_photo'];
                        if (file_exists($oldFile)) {
                            unlink($oldFile);
                        }
                    }
                }
            } elseif ($employeeId) {
                // Giữ nguyên ảnh cũ nếu không upload ảnh mới
                $stmt = $pdo->prepare("SELECT photo FROM employees WHERE id = ?");
                $stmt->execute([$employeeId]);
                $employeeData['photo'] = $stmt->fetchColumn();
            }
            
            if ($userId) {
                // Cập nhật user
                $stmt = $pdo->prepare("UPDATE users SET 
                    email = :email, 
                    role = :role, 
                    status = :status 
                    WHERE id = :id");
                $userData['id'] = $userId;
                $stmt->execute($userData);
                
                // Cập nhật employee
                $stmt = $pdo->prepare("UPDATE employees SET 
                    full_name = :full_name,
                    gender = :gender,
                    birth_date = :birth_date,
                    address = :address,
                    phone = :phone,
                    department = :department,
                    position = :position,
                    salary = :salary,
                    hire_date = :hire_date,
                    photo = :photo
                    WHERE id = :id");
                $employeeData['id'] = $employeeId;
                $stmt->execute($employeeData);
                
                $response['message'] = 'Cập nhật thông tin nhân viên thành công';
            } else {
                // Thêm user mới
                $userData['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("INSERT INTO users 
                    (username, password, email, role, status) 
                    VALUES (:username, :password, :email, :role, :status)");
                $stmt->execute($userData);
                $userId = $pdo->lastInsertId();
                
                // Thêm employee mới
                $employeeData['user_id'] = $userId;
                $stmt = $pdo->prepare("INSERT INTO employees 
                    (user_id, full_name, gender, birth_date, address, phone, 
                    department, position, salary, hire_date, photo) 
                    VALUES (:user_id, :full_name, :gender, :birth_date, :address, :phone, 
                    :department, :position, :salary, :hire_date, :photo)");
                $stmt->execute($employeeData);
                $employeeId = $pdo->lastInsertId();
                
                $response['message'] = 'Thêm nhân viên mới thành công';
            }
            
            $response['success'] = true;
            $response['employee_id'] = $employeeId;
            break;
            
        case 'delete':
            // Xóa nhân viên
            $employeeId = $_POST['employee_id'];
            
            // Lấy thông tin để xóa ảnh
            $stmt = $pdo->prepare("SELECT photo, user_id FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($employee) {
                // Xóa employee
                $pdo->prepare("DELETE FROM employees WHERE id = ?")->execute([$employeeId]);
                
                // Xóa user
                $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$employee['user_id']]);
                
                // Xóa ảnh nếu có
                if ($employee['photo']) {
                    $filePath = '../assets/img/uploads/employees/' . $employee['photo'];
                    if (file_exists($filePath)) {
                        unlink($filePath);
                    }
                }
                
                $response['success'] = true;
                $response['message'] = 'Xóa nhân viên thành công';
            } else {
                $response['message'] = 'Không tìm thấy nhân viên';
            }
            break;
            
        default:
            $response['message'] = 'Hành động không hợp lệ';
    }
} catch (PDOException $e) {
    $response['message'] = 'Lỗi cơ sở dữ liệu: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = 'Lỗi: ' . $e->getMessage();
}

echo json_encode($response);
?>