<?php
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'check_in_out':
            // Xử lý chấm công
            $employeeId = $_POST['employee_id'];
            $checkType = $_POST['check_type'];
            $notes = $_POST['notes'] ?? '';
            $today = date('Y-m-d');
            
            // Kiểm tra xem đã có bản ghi hôm nay chưa
            $stmt = $pdo->prepare("SELECT * FROM attendance 
                                  WHERE employee_id = ? AND date = ?");
            $stmt->execute([$employeeId, $today]);
            $record = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $currentTime = date('H:i:s');
            
            if ($record) {
                // Cập nhật check-out nếu đã có check-in
                if ($checkType === 'check_out') {
                    $stmt = $pdo->prepare("UPDATE attendance SET 
                        check_out = ?, 
                        notes = ?
                        WHERE id = ?");
                    $stmt->execute([$currentTime, $notes, $record['id']]);
                    
                    $response['message'] = 'Check-out thành công';
                } else {
                    $response['message'] = 'Bạn đã check-in hôm nay';
                }
            } else {
                // Tạo bản ghi mới cho check-in
                if ($checkType === 'check_in') {
                    // Xác định trạng thái (đi muộn nếu sau 8h30)
                    $status = 'present';
                    if (strtotime($currentTime) > strtotime('08:30:00')) {
                        $status = 'late';
                    }
                    
                    $stmt = $pdo->prepare("INSERT INTO attendance 
                        (employee_id, date, check_in, status, notes) 
                        VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$employeeId, $today, $currentTime, $status, $notes]);
                    
                    $response['message'] = 'Check-in thành công';
                } else {
                    $response['message'] = 'Bạn cần check-in trước khi check-out';
                }
            }
            
            $response['success'] = true;
            break;
            
        case 'get_attendance':
            // Lấy thông tin chấm công để chỉnh sửa
            $attendanceId = $_POST['attendance_id'];
            
            $stmt = $pdo->prepare("SELECT a.*, e.full_name 
                                  FROM attendance a
                                  JOIN employees e ON a.employee_id = e.id
                                  WHERE a.id = ?");
            $stmt->execute([$attendanceId]);
            $record = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($record) {
                ob_start();
                ?>
                <form id="editAttendanceForm">
                    <input type="hidden" name="attendance_id" value="<?= $record['id'] ?>">
                    <input type="hidden" name="action" value="update_attendance">
                    
                    <div class="mb-3">
                        <label class="form-label">Nhân viên</label>
                        <input type="text" class="form-control" value="<?= $record['full_name'] ?>" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_date" class="form-label">Ngày</label>
                        <input type="date" class="form-control" id="edit_date" name="date" 
                               value="<?= $record['date'] ?>" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_check_in" class="form-label">Check-in</label>
                                <input type="time" class="form-control" id="edit_check_in" name="check_in" 
                                       value="<?= $record['check_in'] ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_check_out" class="form-label">Check-out</label>
                                <input type="time" class="form-control" id="edit_check_out" name="check_out" 
                                       value="<?= $record['check_out'] ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_status" class="form-label">Trạng thái</label>
                        <select class="form-select" id="edit_status" name="status" required>
                            <option value="present" <?= $record['status'] === 'present' ? 'selected' : '' ?>>Có mặt</option>
                            <option value="absent" <?= $record['status'] === 'absent' ? 'selected' : '' ?>>Vắng mặt</option>
                            <option value="late" <?= $record['status'] === 'late' ? 'selected' : '' ?>>Đi muộn</option>
                            <option value="leave" <?= $record['status'] === 'leave' ? 'selected' : '' ?>>Nghỉ phép</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_notes" class="form-label">Ghi chú</label>
                        <textarea class="form-control" id="edit_notes" name="notes" rows="3"><?= htmlspecialchars($record['notes']) ?></textarea>
                    </div>
                    
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                    </div>
                </form>
                <?php
                $response['html'] = ob_get_clean();
                $response['success'] = true;
            } else {
                $response['message'] = 'Không tìm thấy bản ghi chấm công';
            }
            break;
            
        case 'update_attendance':
            // Cập nhật chấm công
            $attendanceId = $_POST['attendance_id'];
            $data = [
                'date' => $_POST['date'],
                'check_in' => $_POST['check_in'] ?: null,
                'check_out' => $_POST['check_out'] ?: null,
                'status' => $_POST['status'],
                'notes' => $_POST['notes'] ?: null
            ];
            
            $stmt = $pdo->prepare("UPDATE attendance SET 
                date = :date,
                check_in = :check_in,
                check_out = :check_out,
                status = :status,
                notes = :notes
                WHERE id = :id");
            $data['id'] = $attendanceId;
            $stmt->execute($data);
            
            $response['success'] = true;
            $response['message'] = 'Cập nhật chấm công thành công';
            break;
            
        case 'delete_attendance':
            // Xóa chấm công
            $attendanceId = $_POST['attendance_id'];
            $pdo->prepare("DELETE FROM attendance WHERE id = ?")->execute([$attendanceId]);
            
            $response['success'] = true;
            $response['message'] = 'Xóa bản ghi chấm công thành công';
            break;
            
        default:
            $response['message'] = 'Hành động không hợp lệ';
    }
} catch (PDOException $e) {
    $response['message'] = 'Lỗi cơ sở dữ liệu: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = 'Lỗi: ' . $e->getMessage();
}

echo json_encode($response);
?>