<?php
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'save':
            // Lưu/thêm mới phân công
            $scheduleId = $_POST['schedule_id'] ?? 0;
            $data = [
                'employee_id' => $_POST['employee_id'],
                'title' => $_POST['title'],
                'description' => $_POST['description'] ?? null,
                'start_date' => $_POST['start_date'],
                'end_date' => $_POST['end_date'],
                'status' => $_POST['status'],
                'created_by' => $_POST['created_by']
            ];
            
            if ($scheduleId) {
                // Cập nhật phân công
                $stmt = $pdo->prepare("UPDATE schedules SET 
                    employee_id = :employee_id,
                    title = :title,
                    description = :description,
                    start_date = :start_date,
                    end_date = :end_date,
                    status = :status
                    WHERE id = :id");
                $data['id'] = $scheduleId;
                $stmt->execute($data);
                
                $response['message'] = 'Cập nhật phân công thành công';
            } else {
                // Thêm phân công mới
                $stmt = $pdo->prepare("INSERT INTO schedules 
                    (employee_id, title, description, start_date, end_date, status, created_by) 
                    VALUES (:employee_id, :title, :description, :start_date, :end_date, :status, :created_by)");
                $stmt->execute($data);
                $scheduleId = $pdo->lastInsertId();
                
                $response['message'] = 'Thêm phân công mới thành công';
            }
            
            $response['success'] = true;
            $response['schedule_id'] = $scheduleId;
            break;
            
        case 'get_schedule':
            // Lấy thông tin phân công
            $scheduleId = $_POST['schedule_id'];
            
            $stmt = $pdo->prepare("SELECT s.*, e.full_name as employee_name, u.username as created_by_name
                                  FROM schedules s
                                  JOIN employees e ON s.employee_id = e.id
                                  JOIN users u ON s.created_by = u.id
                                  WHERE s.id = ?");
            $stmt->execute([$scheduleId]);
            $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($schedule) {
                ob_start();
                ?>
                <div class="mb-3">
                    <h5><?= htmlspecialchars($schedule['title']) ?></h5>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Nhân viên:</strong> <?= htmlspecialchars($schedule['employee_name']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Trạng thái:</strong> 
                            <?php 
                            $statusText = [
                                'pending' => 'Chờ thực hiện',
                                'in_progress' => 'Đang thực hiện',
                                'completed' => 'Hoàn thành',
                                'cancelled' => 'Đã hủy'
                            ];
                            ?>
                            <span class="badge bg-<?= $schedule['status'] === 'pending' ? 'warning' : 
                                                   ($schedule['status'] === 'in_progress' ? 'info' : 
                                                   ($schedule['status'] === 'completed' ? 'success' : 'danger')) ?>">
                                <?= $statusText[$schedule['status']] ?>
                            </span>
                        </p>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Bắt đầu:</strong> <?= date('d/m/Y H:i', strtotime($schedule['start_date'])) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Kết thúc:</strong> <?= date('d/m/Y H:i', strtotime($schedule['end_date'])) ?></p>
                    </div>
                </div>
                
                <div class="mb-3">
                    <p><strong>Người tạo:</strong> <?= htmlspecialchars($schedule['created_by_name']) ?></p>
                </div>
                
                <div class="mb-3">
                    <h6>Mô tả:</h6>
                    <div class="border p-3 rounded bg-light">
                        <?= $schedule['description'] ? nl2br(htmlspecialchars($schedule['description'])) : 'Không có mô tả' ?>
                    </div>
                </div>
                <?php
                $response['html'] = ob_get_clean();
                $response['success'] = true;
            } else {
                $response['message'] = 'Không tìm thấy phân công';
            }
            break;
            
        case 'delete_schedule':
            // Xóa phân công
            $scheduleId = $_POST['schedule_id'];
            $pdo->prepare("DELETE FROM schedules WHERE id = ?")->execute([$scheduleId]);
            
            $response['success'] = true;
            $response['message'] = 'Xóa phân công thành công';
            break;
            
        default:
            $response['message'] = 'Hành động không hợp lệ';
    }
} catch (PDOException $e) {
    $response['message'] = 'Lỗi cơ sở dữ liệu: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = 'Lỗi: ' . $e->getMessage();
}

echo json_encode($response);
?>