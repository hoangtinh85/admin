<?php
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    if (!isset($_POST['type']) || empty($_FILES['image'])) {
        throw new Exception('Invalid request');
    }

    $type = $_POST['type'];
    $uploadDir = '../assets/img/uploads/';
    
    switch ($type) {
        case 'employee':
            $uploadDir .= 'employees/';
            break;
        case 'room':
            $uploadDir .= 'rooms/';
            break;
        default:
            throw new Exception('Invalid upload type');
    }

    $filename = upload_image($_FILES['image'], $uploadDir);
    
    $response['success'] = true;
    $response['filename'] = $filename;
    $response['path'] = str_replace('../', '', $uploadDir) . $filename;
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>