<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();
require_role('admin');

// Lấy danh sách quyền
$stmt = $pdo->query("SELECT p.*, 
                    GROUP_CONCAT(rp.role ORDER BY rp.role SEPARATOR ', ') as roles
                    FROM permissions p
                    LEFT JOIN role_permissions rp ON p.id = rp.permission_id
                    GROUP BY p.id
                    ORDER BY p.name");
$permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy danh sách vai trò
$roles = ['admin', 'manager', 'employee'];

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Quản lý phân quyền</h5>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addPermissionModal">
                <i class="fas fa-plus"></i> Thêm quyền
            </button>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="permissionsTable" class="table table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tên quyền</th>
                        <th>Mô tả</th>
                        <th>Vai trò có quyền</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($permissions as $index => $permission): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($permission['name']) ?></td>
                        <td><?= htmlspecialchars($permission['description']) ?></td>
                        <td>
                            <?php if ($permission['roles']): ?>
                            <?= str_replace(['admin', 'manager', 'employee'], 
                                           ['Quản trị viên', 'Quản lý', 'Nhân viên'], 
                                           $permission['roles']) ?>
                            <?php else: ?>
                            Không có
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-warning edit-permission" 
                                        data-id="<?= $permission['id'] ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger delete-permission" 
                                        data-id="<?= $permission['id'] ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Permission Modal -->
<div class="modal fade" id="addPermissionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Thêm quyền mới</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addPermissionForm">
                    <div class="mb-3">
                        <label for="permission_name" class="form-label">Tên quyền *</label>
                        <input type="text" class="form-control" id="permission_name" name="name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="permission_description" class="form-label">Mô tả</label>
                        <textarea class="form-control" id="permission_description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Áp dụng cho vai trò</label>
                        <?php foreach ($roles as $role): ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="roles[]" 
                                   value="<?= $role ?>" id="role_<?= $role ?>">
                            <label class="form-check-label" for="role_<?= $role ?>">
                                <?= $role === 'admin' ? 'Quản trị viên' : 
                                   ($role === 'manager' ? 'Quản lý' : 'Nhân viên') ?>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-primary" id="savePermission">Lưu</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Permission Modal -->
<div class="modal fade" id="editPermissionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa quyền</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editPermissionModalBody">
                <!-- Nội dung sẽ được load bằng AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deletePermissionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Xác nhận xóa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Bạn có chắc chắn muốn xóa quyền này? Hành động này sẽ ảnh hưởng đến phân quyền của các vai trò.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-danger" id="confirmDeletePermission">Xóa</button>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>