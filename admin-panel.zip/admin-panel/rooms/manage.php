<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$title = 'Manage Room';

// Lấy ID phòng từ URL
$roomId = $_GET['id'] ?? 0;

// Lấy thông tin phòng
$stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
$stmt->execute([$roomId]);
$room = $stmt->fetch();

if (!$room) {
    header('Location: index.php');
    exit;
}

// Lấy các đặc điểm của phòng
$featuresStmt = $pdo->prepare("SELECT f.id, f.name 
                              FROM room_features rf 
                              JOIN features f ON rf.features_id = f.id 
                              WHERE rf.room_id = ?");
$featuresStmt->execute([$roomId]);
$features = $featuresStmt->fetchAll();

// Lấy các tiện ích của phòng
$facilitiesStmt = $pdo->prepare("SELECT f.id, f.name, f.icon 
                                FROM room_facilities rf 
                                JOIN facilities f ON rf.facilities_id = f.id 
                                WHERE rf.room_id = ?");
$facilitiesStmt->execute([$roomId]);
$facilities = $facilitiesStmt->fetchAll();

// Lấy hình ảnh của phòng
$imagesStmt = $pdo->prepare("SELECT * FROM room_images WHERE room_id = ? ORDER BY thumb DESC");
$imagesStmt->execute([$roomId]);
$images = $imagesStmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Manage Room: <?= htmlspecialchars($room['name']) ?></h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="index.php" class="btn btn-secondary me-2">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editRoomModal">
            <i class="fas fa-edit"></i> Edit Room
        </button>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <!-- Room Images Carousel -->
        <div id="roomCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <?php foreach ($images as $key => $image): ?>
                <button type="button" data-bs-target="#roomCarousel" data-bs-slide-to="<?= $key ?>" 
                        class="<?= $key === 0 ? 'active' : '' ?>" aria-current="<?= $key === 0 ? 'true' : '' ?>"></button>
                <?php endforeach; ?>
            </div>
            <div class="carousel-inner rounded">
                <?php foreach ($images as $key => $image): ?>
                <div class="carousel-item <?= $key === 0 ? 'active' : '' ?>">
                    <img src="../../assets/uploads/rooms/<?= htmlspecialchars($image['image']) ?>" 
                         class="d-block w-100" alt="Room Image">
                </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#roomCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#roomCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <!-- Room Description -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Description</h5>
            </div>
            <div class="card-body">
                <?= $room['description'] ? nl2br(htmlspecialchars($room['description'])) : '<p class="text-muted">No description provided</p>' ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <!-- Room Details -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Room Details</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Area
                        <span class="badge bg-primary rounded-pill"><?= $room['area'] ?> sq.ft</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Price
                        <span class="badge bg-success rounded-pill">£<?= number_format($room['price'], 2) ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Quantity
                        <span class="badge bg-info rounded-pill"><?= $room['quantity'] ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Max Adults
                        <span class="badge bg-warning rounded-pill"><?= $room['adult'] ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Max Children
                        <span class="badge bg-danger rounded-pill"><?= $room['children'] ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Status
                        <span class="badge bg-<?= $room['status'] ? 'success' : 'secondary' ?> rounded-pill">
                            <?= $room['status'] ? 'Active' : 'Inactive' ?>
                        </span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Room Features -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Features</h5>
            </div>
            <div class="card-body">
                <?php if (count($features) > 0): ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($features as $feature): ?>
                    <li class="list-group-item"><?= htmlspecialchars($feature['name']) ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                <p class="text-muted">No features added</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Room Facilities -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Facilities</h5>
            </div>
            <div class="card-body">
                <?php if (count($facilities) > 0): ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($facilities as $facility): ?>
                    <li class="list-group-item">
                        <i class="<?= htmlspecialchars($facility['icon']) ?> me-2"></i>
                        <?= htmlspecialchars($facility['name']) ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                <p class="text-muted">No facilities added</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Edit Room Modal -->
<div class="modal fade" id="editRoomModal" tabindex="-1" aria-labelledby="editRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Room</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editRoomForm">
                <input type="hidden" name="id" value="<?= $room['id'] ?>">
                <input type="hidden" name="action" value="update_room">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Room Name</label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?= htmlspecialchars($room['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="area" class="form-label">Area (sq.ft)</label>
                                <input type="number" class="form-control" id="area" name="area" 
                                       value="<?= $room['area'] ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">Price (£)</label>
                                <input type="number" step="0.01" class="form-control" id="price" name="price" 
                                       value="<?= $room['price'] ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" 
                                       value="<?= $room['quantity'] ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="adult" class="form-label">Max Adults</label>
                                <input type="number" class="form-control" id="adult" name="adult" 
                                       value="<?= $room['adult'] ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="children" class="form-label">Max Children</label>
                                <input type="number" class="form-control" id="children" name="children" 
                                       value="<?= $room['children'] ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($room['description']) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="status" name="status" 
                                   <?= $room['status'] ? 'checked' : '' ?>>
                            <label class="form-check-label" for="status">Active</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    // Handle edit room form submission
    $('#editRoomForm').submit(function(e) {
        e.preventDefault();
        
        $.post('room_ajax.php', $(this).serialize(), function(response) {
            if (response.success) {
                $('#editRoomModal').modal('hide');
                location.reload();
            } else {
                alert('Error updating room: ' + response.message);
            }
        }, 'json');
    });
});
</script>