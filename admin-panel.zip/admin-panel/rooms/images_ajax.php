<?php
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'get_images':
            getImages();
            break;
        case 'upload_images':
            uploadImages();
            break;
        case 'delete_image':
            deleteImage();
            break;
        case 'set_thumbnail':
            setThumbnail();
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

function getImages() {
    global $pdo;
    
    if (empty($_GET['room_id'])) {
        echo json_encode(['success' => false, 'message' => 'Room ID is required']);
        return;
    }
    
    $roomId = $_GET['room_id'];
    
    $stmt = $pdo->prepare("SELECT * FROM room_images WHERE room_id = ? ORDER BY thumb DESC, sr_no ASC");
    $stmt->execute([$roomId]);
    $images = $stmt->fetchAll();
    
    ob_start();
    ?>
    <div class="row">
        <?php foreach ($images as $image): ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <img src="<?= '../../assets/uploads/rooms/' . htmlspecialchars($image['image']) ?>" 
                     class="card-img-top" alt="Room Image">
                <div class="card-body text-center">
                    <?php if ($image['thumb']): ?>
                    <span class="badge bg-success mb-2">Thumbnail</span>
                    <?php else: ?>
                    <button class="btn btn-sm btn-outline-primary set-thumbnail mb-2" 
                            data-id="<?= $image['sr_no'] ?>">
                        Set as Thumbnail
                    </button>
                    <?php endif; ?>
                    <button class="btn btn-sm btn-outline-danger delete-image" 
                            data-id="<?= $image['sr_no'] ?>">
                        Delete
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    $html = ob_get_clean();
    
    echo json_encode(['success' => true, 'html' => $html]);
}

function uploadImages() {
    global $pdo;
    
    if (empty($_POST['room_id']) || empty($_FILES['new_images'])) {
        echo json_encode(['success' => false, 'message' => 'Room ID and images are required']);
        return;
    }
    
    $roomId = $_POST['room_id'];
    $uploadDir = '../../assets/uploads/rooms/';
    
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO room_images (room_id, image, thumb) VALUES (?, ?, ?)");
        
        // Check if room has any images (to determine if we should set thumb)
        $thumbCheck = $pdo->prepare("SELECT COUNT(*) FROM room_images WHERE room_id = ?");
        $thumbCheck->execute([$roomId]);
        $hasImages = $thumbCheck->fetchColumn() > 0;
        
        foreach ($_FILES['new_images']['tmp_name'] as $key => $tmpName) {
            if ($_FILES['new_images']['error'][$key] === UPLOAD_ERR_OK) {
                $fileName = uniqid() . '_' . basename($_FILES['new_images']['name'][$key]);
                $targetPath = $uploadDir . $fileName;
                
                if (move_uploaded_file($tmpName, $targetPath)) {
                    // Set as thumb only if this is the first image for the room
                    $isThumb = !$hasImages ? 1 : 0;
                    $hasImages = true; // Subsequent images won't be thumb
                    
                    $stmt->execute([$roomId, $fileName, $isThumb]);
                }
            }
        }
        
        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error uploading images: ' . $e->getMessage()]);
    }
}

function deleteImage() {
    global $pdo;
    
    if (empty($_POST['id'])) {
        echo json_encode(['success' => false, 'message' => 'Image ID is required']);
        return;
    }
    
    $imageId = $_POST['id'];
    
    try {
        $pdo->beginTransaction();
        
        // Get image info before deleting
        $stmt = $pdo->prepare("SELECT room_id, image, thumb FROM room_images WHERE sr_no = ?");
        $stmt->execute([$imageId]);
        $image = $stmt->fetch();
        
        if (!$image) {
            throw new Exception('Image not found');
        }
        
        // Delete from database
        $pdo->prepare("DELETE FROM room_images WHERE sr_no = ?")->execute([$imageId]);
        
        // Delete file
        $filePath = '../../assets/uploads/rooms/' . $image['image'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        // If this was the thumbnail, set another image as thumbnail
        if ($image['thumb']) {
            $newThumb = $pdo->prepare("SELECT sr_no FROM room_images WHERE room_id = ? LIMIT 1");
            $newThumb->execute([$image['room_id']]);
            $newThumbId = $newThumb->fetchColumn();
            
            if ($newThumbId) {
                $pdo->prepare("UPDATE room_images SET thumb = 1 WHERE sr_no = ?")->execute([$newThumbId]);
            }
        }
        
        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error deleting image: ' . $e->getMessage()]);
    }
}

function setThumbnail() {
    global $pdo;
    
    if (empty($_POST['id']) || empty($_POST['room_id'])) {
        echo json_encode(['success' => false, 'message' => 'Image ID and Room ID are required']);
        return;
    }
    
    $imageId = $_POST['id'];
    $roomId = $_POST['room_id'];
    
    try {
        $pdo->beginTransaction();
        
        // Reset all thumbnails for this room
        $pdo->prepare("UPDATE room_images SET thumb = 0 WHERE room_id = ?")->execute([$roomId]);
        
        // Set the selected image as thumbnail
        $pdo->prepare("UPDATE room_images SET thumb = 1 WHERE sr_no = ?")->execute([$imageId]);
        
        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error setting thumbnail: ' . $e->getMessage()]);
    }
}
?>