<?php
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'add_room':
            addRoom();
            break;
        case 'get_room':
            getRoom();
            break;
        case 'update_room':
            updateRoom();
            break;
        case 'delete_room':
            deleteRoom();
            break;
        case 'toggle_status':
            toggleStatus();
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

function addRoom() {
    global $pdo;
    
    // Validate input
    $required = ['name', 'area', 'price', 'quantity', 'adult', 'children', 'language_id'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => "Field $field is required"]);
            return;
        }
    }
    
    // Begin transaction
    $pdo->beginTransaction();
    
    try {
        // Insert room data
        $stmt = $pdo->prepare("INSERT INTO rooms (languages_id, name, area, price, quantity, adult, children, description, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $_POST['language_id'],
            $_POST['name'],
            $_POST['area'],
            $_POST['price'],
            $_POST['quantity'],
            $_POST['adult'],
            $_POST['children'],
            $_POST['description'] ?? ''
        ]);
        
        $roomId = $pdo->lastInsertId();
        
        // Insert features
        if (!empty($_POST['features'])) {
            $featuresStmt = $pdo->prepare("INSERT INTO room_features (room_id, features_id) VALUES (?, ?)");
            foreach ($_POST['features'] as $featureId) {
                $featuresStmt->execute([$roomId, $featureId]);
            }
        }
        
        // Insert facilities
        if (!empty($_POST['facilities'])) {
            $facilitiesStmt = $pdo->prepare("INSERT INTO room_facilities (room_id, facilities_id) VALUES (?, ?)");
            foreach ($_POST['facilities'] as $facilityId) {
                $facilitiesStmt->execute([$roomId, $facilityId]);
            }
        }
        
        // Handle image uploads
        if (!empty($_FILES['images'])) {
            $uploadDir = '../../assets/uploads/rooms/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $imagesStmt = $pdo->prepare("INSERT INTO room_images (room_id, image, thumb) VALUES (?, ?, ?)");
            $thumbSet = false;
            
            foreach ($_FILES['images']['tmp_name'] as $key => $tmpName) {
                if ($_FILES['images']['error'][$key] === UPLOAD_ERR_OK) {
                    $fileName = uniqid() . '_' . basename($_FILES['images']['name'][$key]);
                    $targetPath = $uploadDir . $fileName;
                    
                    if (move_uploaded_file($tmpName, $targetPath)) {
                        // Set first image as thumbnail if none set yet
                        $isThumb = $thumbSet ? 0 : 1;
                        $thumbSet = $thumbSet || $isThumb;
                        
                        $imagesStmt->execute([$roomId, $fileName, $isThumb]);
                    }
                }
            }
        }
        
        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function getRoom() {
    global $pdo;
    
    if (empty($_GET['id'])) {
        echo json_encode(['success' => false, 'message' => 'Room ID is required']);
        return;
    }
    
    $roomId = $_GET['id'];
    
    // Get room data
    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
    $stmt->execute([$roomId]);
    $room = $stmt->fetch();
    
    if (!$room) {
        echo json_encode(['success' => false, 'message' => 'Room not found']);
        return;
    }
    
    // Get room features
    $featuresStmt = $pdo->prepare("SELECT features_id FROM room_features WHERE room_id = ?");
    $featuresStmt->execute([$roomId]);
    $roomFeatures = $featuresStmt->fetchAll(PDO::FETCH_COLUMN, 0);
    
    // Get room facilities
    $facilitiesStmt = $pdo->prepare("SELECT facilities_id FROM room_facilities WHERE room_id = ?");
    $facilitiesStmt->execute([$roomId]);
    $roomFacilities = $facilitiesStmt->fetchAll(PDO::FETCH_COLUMN, 0);
    
    // Get all features for checkbox list
    $allFeatures = $pdo->query("SELECT * FROM features")->fetchAll();
    
    // Get all facilities for checkbox list
    $allFacilities = $pdo->query("SELECT * FROM facilities")->fetchAll();
    
    // Get all languages for dropdown
    $languages = $pdo->query("SELECT * FROM languages")->fetchAll();
    
    // Generate HTML for edit modal
    ob_start();
    ?>
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">Edit Room</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="editRoomForm">
            <input type="hidden" name="id" value="<?= $room['id'] ?>">
            <input type="hidden" name="action" value="update_room">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Room Name</label>
                            <input type="text" class="form-control" id="edit_name" name="name" 
                                   value="<?= htmlspecialchars($room['name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_area" class="form-label">Area (sq.ft)</label>
                            <input type="number" class="form-control" id="edit_area" name="area" 
                                   value="<?= $room['area'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_price" class="form-label">Price (£)</label>
                            <input type="number" step="0.01" class="form-control" id="edit_price" name="price" 
                                   value="<?= $room['price'] ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="edit_quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="edit_quantity" name="quantity" 
                                   value="<?= $room['quantity'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_adult" class="form-label">Max Adults</label>
                            <input type="number" class="form-control" id="edit_adult" name="adult" 
                                   value="<?= $room['adult'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_children" class="form-label">Max Children</label>
                            <input type="number" class="form-control" id="edit_children" name="children" 
                                   value="<?= $room['children'] ?>" required>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="edit_description" class="form-label">Description</label>
                    <textarea class="form-control" id="edit_description" name="description" rows="3"><?= htmlspecialchars($room['description']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Features</label>
                    <div class="features-container row">
                        <?php foreach ($allFeatures as $feature): ?>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="features[]" 
                                       value="<?= $feature['id'] ?>" id="edit_feature_<?= $feature['id'] ?>"
                                       <?= in_array($feature['id'], $roomFeatures) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="edit_feature_<?= $feature['id'] ?>">
                                    <?= htmlspecialchars($feature['name']) ?>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Facilities</label>
                    <div class="facilities-container row">
                        <?php foreach ($allFacilities as $facility): ?>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="facilities[]" 
                                       value="<?= $facility['id'] ?>" id="edit_facility_<?= $facility['id'] ?>"
                                       <?= in_array($facility['id'], $roomFacilities) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="edit_facility_<?= $facility['id'] ?>">
                                    <i class="<?= $facility['icon'] ?> me-1"></i>
                                    <?= htmlspecialchars($facility['name']) ?>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="edit_language_id" class="form-label">Language</label>
                    <select class="form-select" id="edit_language_id" name="language_id" required>
                        <?php foreach ($languages as $language): ?>
                        <option value="<?= $language['id'] ?>" <?= $language['id'] == $room['languages_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($language['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Update Room</button>
            </div>
        </form>
    </div>
    <script>
    $(document).ready(function() {
        $('#editRoomForm').submit(function(e) {
            e.preventDefault();
            
            $.post('room_ajax.php', $(this).serialize(), function(response) {
                if (response.success) {
                    $('#editRoomModal').modal('hide');
                    location.reload();
                } else {
                    alert(response.message || 'Error updating room');
                }
            }, 'json');
        });
    });
    </script>
    <?php
    $html = ob_get_clean();
    
    echo json_encode(['success' => true, 'html' => $html]);
}

function updateRoom() {
    global $pdo;
    
    // Validate input
    $required = ['id', 'name', 'area', 'price', 'quantity', 'adult', 'children', 'language_id'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => "Field $field is required"]);
            return;
        }
    }
    
    $roomId = $_POST['id'];
    
    // Begin transaction
    $pdo->beginTransaction();
    
    try {
        // Update room data
        $stmt = $pdo->prepare("UPDATE rooms SET 
                              languages_id = ?, 
                              name = ?, 
                              area = ?, 
                              price = ?, 
                              quantity = ?, 
                              adult = ?, 
                              children = ?, 
                              description = ? 
                              WHERE id = ?");
        $stmt->execute([
            $_POST['language_id'],
            $_POST['name'],
            $_POST['area'],
            $_POST['price'],
            $_POST['quantity'],
            $_POST['adult'],
            $_POST['children'],
            $_POST['description'] ?? '',
            $roomId
        ]);
        
        // Update features - first delete existing, then insert new
        $pdo->prepare("DELETE FROM room_features WHERE room_id = ?")->execute([$roomId]);
        
        if (!empty($_POST['features'])) {
            $featuresStmt = $pdo->prepare("INSERT INTO room_features (room_id, features_id) VALUES (?, ?)");
            foreach ($_POST['features'] as $featureId) {
                $featuresStmt->execute([$roomId, $featureId]);
            }
        }
        
        // Update facilities - first delete existing, then insert new
        $pdo->prepare("DELETE FROM room_facilities WHERE room_id = ?")->execute([$roomId]);
        
        if (!empty($_POST['facilities'])) {
            $facilitiesStmt = $pdo->prepare("INSERT INTO room_facilities (room_id, facilities_id) VALUES (?, ?)");
            foreach ($_POST['facilities'] as $facilityId) {
                $facilitiesStmt->execute([$roomId, $facilityId]);
            }
        }
        
        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function deleteRoom() {
    global $pdo;
    
    if (empty($_POST['id'])) {
        echo json_encode(['success' => false, 'message' => 'Room ID is required']);
        return;
    }
    
    $roomId = $_POST['id'];
    
    // Soft delete - set removed flag
    $stmt = $pdo->prepare("UPDATE rooms SET removed = 1 WHERE id = ?");
    $stmt->execute([$roomId]);
    
    echo json_encode(['success' => true]);
}

function toggleStatus() {
    global $pdo;
    
    if (empty($_POST['id']) || !isset($_POST['status'])) {
        echo json_encode(['success' => false, 'message' => 'Room ID and status are required']);
        return;
    }
    
    $roomId = $_POST['id'];
    $status = $_POST['status'] ? 1 : 0;
    
    $stmt = $pdo->prepare("UPDATE rooms SET status = ? WHERE id = ?");
    $stmt->execute([$status, $roomId]);
    
    echo json_encode(['success' => true]);
}
?>