<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$title = 'Room Management';

// Lấy danh sách phòng
$stmt = $pdo->query("SELECT * FROM rooms WHERE removed = 0");
$rooms = $stmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Room Management</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRoomModal">
            <i class="fas fa-plus me-1"></i> Add New Room
        </button>
    </div>
</div>

<div class="table-responsive">
    <table id="roomsTable" class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Area (sq.ft)</th>
                <th>Guests</th>
                <th>Price (£)</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rooms as $room): ?>
            <tr>
                <td><?= $room['id'] ?></td>
                <td><?= htmlspecialchars($room['name']) ?></td>
                <td><?= $room['area'] ?></td>
                <td>Adult: <?= $room['adult'] ?><br>Children: <?= $room['children'] ?></td>
                <td><?= number_format($room['price'], 2) ?></td>
                <td><?= $room['quantity'] ?></td>
                <td>
                    <div class="form-check form-switch">
                        <input class="form-check-input status-toggle" type="checkbox" 
                               data-id="<?= $room['id'] ?>" <?= $room['status'] ? 'checked' : '' ?>>
                    </div>
                </td>
                <td>
                    <button class="btn btn-sm btn-warning edit-room" data-id="<?= $room['id'] ?>">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger delete-room" data-id="<?= $room['id'] ?>">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn btn-sm btn-info manage-images" data-id="<?= $room['id'] ?>" data-name="<?= htmlspecialchars($room['name']) ?>">
                        <i class="fas fa-images"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Add Room Modal -->
<div class="modal fade" id="addRoomModal" tabindex="-1" aria-labelledby="addRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addRoomModalLabel">Add New Room</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addRoomForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Room Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="area" class="form-label">Area (sq.ft)</label>
                                <input type="number" class="form-control" id="area" name="area" required>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">Price (£)</label>
                                <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" required>
                            </div>
                            <div class="mb-3">
                                <label for="adult" class="form-label">Max Adults</label>
                                <input type="number" class="form-control" id="adult" name="adult" required>
                            </div>
                            <div class="mb-3">
                                <label for="children" class="form-label">Max Children</label>
                                <input type="number" class="form-control" id="children" name="children" required>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Features</label>
                        <div class="features-container row">
                            <?php
                            $features = $pdo->query("SELECT * FROM features")->fetchAll();
                            foreach ($features as $feature): ?>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="features[]" 
                                           value="<?= $feature['id'] ?>" id="feature_<?= $feature['id'] ?>">
                                    <label class="form-check-label" for="feature_<?= $feature['id'] ?>">
                                        <?= htmlspecialchars($feature['name']) ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Facilities</label>
                        <div class="facilities-container row">
                            <?php
                            $facilities = $pdo->query("SELECT * FROM facilities")->fetchAll();
                            foreach ($facilities as $facility): ?>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="facilities[]" 
                                           value="<?= $facility['id'] ?>" id="facility_<?= $facility['id'] ?>">
                                    <label class="form-check-label" for="facility_<?= $facility['id'] ?>">
                                        <i class="<?= $facility['icon'] ?> me-1"></i>
                                        <?= htmlspecialchars($facility['name']) ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="language_id" class="form-label">Language</label>
                        <select class="form-select" id="language_id" name="language_id" required>
                            <?php
                            $languages = $pdo->query("SELECT * FROM languages")->fetchAll();
                            foreach ($languages as $language): ?>
                            <option value="<?= $language['id'] ?>"><?= htmlspecialchars($language['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="images" class="form-label">Room Images</label>
                        <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Room</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Room Modal -->
<div class="modal fade" id="editRoomModal" tabindex="-1" aria-labelledby="editRoomModalLabel" aria-hidden="true">
    <!-- Similar to add modal but will be populated via AJAX -->
</div>

<!-- Images Management Modal -->
<div class="modal fade" id="imagesModal" tabindex="-1" aria-labelledby="imagesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imagesModalLabel">Manage Room Images</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="uploadImageForm" enctype="multipart/form-data">
                    <input type="hidden" id="room_id" name="room_id">
                    <div class="mb-3">
                        <label for="new_images" class="form-label">Upload New Images</label>
                        <input type="file" class="form-control" id="new_images" name="new_images[]" multiple accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </form>
                <hr>
                <div class="row" id="imagesContainer">
                    <!-- Images will be loaded here via AJAX -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    // Initialize DataTable
    $('#roomsTable').DataTable({
        responsive: true
    });
    
    // Handle status toggle
    $('.status-toggle').change(function() {
        const roomId = $(this).data('id');
        const isActive = $(this).is(':checked') ? 1 : 0;
        
        $.post('room_ajax.php', {
            action: 'toggle_status',
            id: roomId,
            status: isActive
        }, function(response) {
            if (!response.success) {
                alert('Error updating status');
                location.reload();
            }
        }, 'json');
    });
    
    // Handle add room form submission
    $('#addRoomForm').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'add_room');
        
        $.ajax({
            url: 'room_ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $('#addRoomModal').modal('hide');
                    location.reload();
                } else {
                    alert(response.message || 'Error adding room');
                }
            },
            dataType: 'json'
        });
    });
    
    // Handle edit button click
    $(document).on('click', '.edit-room', function() {
        const roomId = $(this).data('id');
        
        $.get('room_ajax.php', {action: 'get_room', id: roomId}, function(response) {
            if (response.success) {
                $('#editRoomModal').html(response.html);
                $('#editRoomModal').modal('show');
            } else {
                alert('Error loading room data');
            }
        }, 'json');
    });
    
    // Handle delete button click
    $(document).on('click', '.delete-room', function() {
        if (confirm('Are you sure you want to delete this room?')) {
            const roomId = $(this).data('id');
            
            $.post('room_ajax.php', {
                action: 'delete_room',
                id: roomId
            }, function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error deleting room');
                }
            }, 'json');
        }
    });
    
    // Handle manage images button click
    $(document).on('click', '.manage-images', function() {
        const roomId = $(this).data('id');
        const roomName = $(this).data('name');
        
        $('#imagesModalLabel').text('Manage Images for ' + roomName);
        $('#room_id').val(roomId);
        
        // Load existing images
        $.get('images_ajax.php', {action: 'get_images', room_id: roomId}, function(response) {
            if (response.success) {
                $('#imagesContainer').html(response.html);
            } else {
                alert('Error loading images');
            }
        }, 'json');
        
        $('#imagesModal').modal('show');
    });
    
    // Handle upload image form submission
    $('#uploadImageForm').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'upload_images');
        
        $.ajax({
            url: 'images_ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    // Refresh images list
                    const roomId = $('#room_id').val();
                    $.get('images_ajax.php', {action: 'get_images', room_id: roomId}, function(response) {
                        if (response.success) {
                            $('#imagesContainer').html(response.html);
                            $('#new_images').val('');
                        } else {
                            alert('Error loading images after upload');
                        }
                    }, 'json');
                } else {
                    alert(response.message || 'Error uploading images');
                }
            },
            dataType: 'json'
        });
    });
    
    // Handle delete image button click (delegated event)
    $(document).on('click', '.delete-image', function() {
        if (confirm('Are you sure you want to delete this image?')) {
            const imageId = $(this).data('id');
            const roomId = $('#room_id').val();
            
            $.post('images_ajax.php', {
                action: 'delete_image',
                id: imageId
            }, function(response) {
                if (response.success) {
                    // Refresh images list
                    $.get('images_ajax.php', {action: 'get_images', room_id: roomId}, function(response) {
                        if (response.success) {
                            $('#imagesContainer').html(response.html);
                        } else {
                            alert('Error loading images after delete');
                        }
                    }, 'json');
                } else {
                    alert('Error deleting image');
                }
            }, 'json');
        }
    });
    
    // Handle set thumbnail button click (delegated event)
    $(document).on('click', '.set-thumbnail', function() {
        const imageId = $(this).data('id');
        const roomId = $('#room_id').val();
        
        $.post('images_ajax.php', {
            action: 'set_thumbnail',
            id: imageId,
            room_id: roomId
        }, function(response) {
            if (response.success) {
                // Refresh images list
                $.get('images_ajax.php', {action: 'get_images', room_id: roomId}, function(response) {
                    if (response.success) {
                        $('#imagesContainer').html(response.html);
                    } else {
                        alert('Error loading images after setting thumbnail');
                    }
                }, 'json');
            } else {
                alert('Error setting thumbnail');
            }
        }, 'json');
    });
});
</script>