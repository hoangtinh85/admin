// Employee management
$(document).on('click', '.delete-employee', function() {
    const employeeId = $(this).data('id');
    $('#deleteModal').modal('show');
    
    $('#confirmDelete').off('click').on('click', function() {
        $.ajax({
            url: '../ajax/employee_actions.php',
            type: 'POST',
            data: {
                action: 'delete',
                employee_id: employeeId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error deleting employee');
            }
        });
    });
});

$('#employeeForm').submit(function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'save');
    
    if ($('input[name="employee_id"]').val() && $('input[name="old_photo"]').length) {
        formData.append('old_photo', $('input[name="old_photo"]').val());
    }
    
    $.ajax({
        url: '../ajax/employee_actions.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                window.location.href = 'index.php';
            } else {
                alert(response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('Error: ' + error);
        }
    });
});

// Attendance management
$(document).on('click', '.edit-attendance', function() {
    const attendanceId = $(this).data('id');
    
    $.ajax({
        url: '../ajax/attendance_actions.php',
        type: 'POST',
        data: {
            action: 'get_attendance',
            attendance_id: attendanceId
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#editAttendanceModalBody').html(response.html);
                $('#editAttendanceModal').modal('show');
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error loading attendance data');
        }
    });
});

$(document).on('submit', '#editAttendanceForm', function(e) {
    e.preventDefault();
    
    $.ajax({
        url: '../ajax/attendance_actions.php',
        type: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                $('#editAttendanceModal').modal('hide');
                location.reload();
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error updating attendance');
        }
    });
});

$(document).on('click', '.delete-attendance', function() {
    const attendanceId = $(this).data('id');
    $('#deleteAttendanceModal').modal('show');
    
    $('#confirmDeleteAttendance').off('click').on('click', function() {
        $.ajax({
            url: '../ajax/attendance_actions.php',
            type: 'POST',
            data: {
                action: 'delete_attendance',
                attendance_id: attendanceId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error deleting attendance record');
            }
        });
    });
});

$('#submitAttendance').click(function() {
    $.ajax({
        url: '../ajax/attendance_actions.php',
        type: 'POST',
        data: $('#attendanceForm').serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                $('#checkInModal').modal('hide');
                location.reload();
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error processing attendance');
        }
    });
});

// Schedule management
$(document).on('click', '.view-schedule', function() {
    const scheduleId = $(this).data('id');
    
    $.ajax({
        url: '../ajax/schedule_actions.php',
        type: 'POST',
        data: {
            action: 'get_schedule',
            schedule_id: scheduleId
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#viewScheduleModalBody').html(response.html);
                $('#viewScheduleModal').modal('show');
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error loading schedule data');
        }
    });
});

$(document).on('click', '.delete-schedule', function() {
    const scheduleId = $(this).data('id');
    $('#deleteScheduleModal').modal('show');
    
    $('#confirmDeleteSchedule').off('click').on('click', function() {
        $.ajax({
            url: '../ajax/schedule_actions.php',
            type: 'POST',
            data: {
                action: 'delete_schedule',
                schedule_id: scheduleId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error deleting schedule');
            }
        });
    });
});

$('#scheduleForm').submit(function(e) {
    e.preventDefault();
    
    $.ajax({
        url: '../ajax/schedule_actions.php',
        type: 'POST',
        data: $(this).serialize() + '&action=save',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                window.location.href = 'index.php';
            } else {
                alert(response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('Error: ' + error);
        }
    });
});

// User management
$(document).on('click', '.delete-user', function() {
    const userId = $(this).data('id');
    $('#deleteUserModal').modal('show');
    
    $('#confirmDeleteUser').off('click').on('click', function() {
        $.ajax({
            url: '../ajax/user_actions.php',
            type: 'POST',
            data: {
                action: 'delete',
                user_id: userId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error deleting user');
            }
        });
    });
});

$('#userForm').submit(function(e) {
    e.preventDefault();
    
    if (!$('input[name="user_id"]').val() && $('#password').val() !== $('#confirm_password').val()) {
        alert('Mật khẩu xác nhận không khớp');
        return;
    }
    
    $.ajax({
        url: '../ajax/user_actions.php',
        type: 'POST',
        data: $(this).serialize() + '&action=save',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                window.location.href = 'index.php';
            } else {
                alert(response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('Error: ' + error);
        }
    });
});

// Permission management
$('#savePermission').click(function() {
    const formData = $('#addPermissionForm').serialize() + '&action=add_permission';
    
    $.ajax({
        url: '../ajax/permission_actions.php',
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                $('#addPermissionModal').modal('hide');
                location.reload();
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error adding permission');
        }
    });
});

$(document).on('click', '.edit-permission', function() {
    const permissionId = $(this).data('id');
    
    $.ajax({
        url: '../ajax/permission_actions.php',
        type: 'POST',
        data: {
            action: 'get_permission',
            permission_id: permissionId
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#editPermissionModalBody').html(response.html);
                $('#editPermissionModal').modal('show');
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error loading permission data');
        }
    });
});

$(document).on('submit', '#editPermissionForm', function(e) {
    e.preventDefault();
    
    $.ajax({
        url: '../ajax/permission_actions.php',
        type: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert(response.message);
                $('#editPermissionModal').modal('hide');
                location.reload();
            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Error updating permission');
        }
    });
});

$(document).on('click', '.delete-permission', function() {
    const permissionId = $(this).data('id');
    $('#deletePermissionModal').modal('show');
    
    $('#confirmDeletePermission').off('click').on('click', function() {
        $.ajax({
            url: '../ajax/permission_actions.php',
            type: 'POST',
            data: {
                action: 'delete_permission',
                permission_id: permissionId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error deleting permission');
            }
        });
    });
});