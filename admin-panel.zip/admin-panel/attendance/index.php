<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();

// Chỉ admin và manager mới được xem tất cả chấm công
if ($_SESSION['role'] === 'employee') {
    $employeeId = $_SESSION['employee_id'] ?? 0;
    if (!$employeeId) {
        header('Location: ../dashboard.php');
        exit();
    }
    
    $stmt = $pdo->prepare("SELECT a.* FROM attendance a 
                          WHERE a.employee_id = ? 
                          ORDER BY a.date DESC");
    $stmt->execute([$employeeId]);
} else {
    $stmt = $pdo->query("SELECT a.*, e.full_name 
                        FROM attendance a
                        JOIN employees e ON a.employee_id = e.id
                        ORDER BY a.date DESC");
}

$attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Quản lý chấm công</h5>
            <?php if (has_permission('create_attendance')): ?>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#checkInModal">
                <i class="fas fa-fingerprint"></i> Chấm công
            </button>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="attendanceTable" class="table table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nhân viên</th>
                        <th>Ngày</th>
                        <th>Check-in</th>
                        <th>Check-out</th>
                        <th>Trạng thái</th>
                        <th>Ghi chú</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance as $index => $record): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= $record['full_name'] ?? $_SESSION['full_name'] ?></td>
                        <td><?= date('d/m/Y', strtotime($record['date'])) ?></td>
                        <td><?= $record['check_in'] ? date('H:i', strtotime($record['check_in'])) : '--:--' ?></td>
                        <td><?= $record['check_out'] ? date('H:i', strtotime($record['check_out'])) : '--:--' ?></td>
                        <td>
                            <?php 
                            $statusClass = [
                                'present' => 'success',
                                'absent' => 'danger',
                                'late' => 'warning',
                                'leave' => 'info'
                            ];
                            ?>
                            <span class="badge bg-<?= $statusClass[$record['status']] ?>">
                                <?= $record['status'] === 'present' ? 'Có mặt' : 
                                   ($record['status'] === 'absent' ? 'Vắng mặt' : 
                                   ($record['status'] === 'late' ? 'Đi muộn' : 'Nghỉ phép')) ?>
                            </span>
                        </td>
                        <td><?= $record['notes'] ? htmlspecialchars($record['notes']) : '---' ?></td>
                        <td>
                            <div class="btn-group">
                                <?php if (has_permission('edit_attendance')): ?>
                                <button class="btn btn-sm btn-warning edit-attendance" 
                                        data-id="<?= $record['id'] ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <?php endif; ?>
                                <?php if (has_permission('delete_attendance')): ?>
                                <button class="btn btn-sm btn-danger delete-attendance" 
                                        data-id="<?= $record['id'] ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Check-in/Check-out Modal -->
<div class="modal fade" id="checkInModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chấm công</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="attendanceForm">
                    <input type="hidden" name="employee_id" value="<?= $_SESSION['employee_id'] ?>">
                    <input type="hidden" name="action" value="check_in_out">
                    
                    <div class="mb-3">
                        <label class="form-label">Loại chấm công</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="check_type" id="checkIn" value="check_in" checked>
                            <label class="form-check-label" for="checkIn">Check-in</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="check_type" id="checkOut" value="check_out">
                            <label class="form-check-label" for="checkOut">Check-out</label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Ghi chú</label>
                        <textarea class="form-control" id="notes" name="notes" rows="2"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                <button type="button" class="btn btn-primary" id="submitAttendance">Xác nhận</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Attendance Modal -->
<div class="modal fade" id="editAttendanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa chấm công</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editAttendanceModalBody">
                <!-- Nội dung sẽ được load bằng AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteAttendanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Xác nhận xóa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Bạn có chắc chắn muốn xóa bản ghi chấm công này?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteAttendance">Xóa</button>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>