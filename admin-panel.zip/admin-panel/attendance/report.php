<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_login();
require_role(['admin', 'manager']);

// Xử lý báo cáo chấm công
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-t');

$stmt = $pdo->prepare("SELECT a.*, e.full_name 
                      FROM attendance a
                      JOIN employees e ON a.employee_id = e.id
                      WHERE a.date BETWEEN ? AND ?
                      ORDER BY a.date DESC");
$stmt->execute([$startDate, $endDate]);
$attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Báo cáo chấm công</h5>
    </div>
    <div class="card-body">
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Từ ngày</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?= $startDate ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Đến ngày</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?= $endDate ?>">
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">Lọc</button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Ngày</th>
                        <th>Nhân viên</th>
                        <th>Check-in</th>
                        <th>Check-out</th>
                        <th>Trạng thái</th>
                        <th>Ghi chú</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance as $record): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($record['date'])) ?></td>
                        <td><?= htmlspecialchars($record['full_name']) ?></td>
                        <td><?= $record['check_in'] ? date('H:i', strtotime($record['check_in'])) : '--:--' ?></td>
                        <td><?= $record['check_out'] ? date('H:i', strtotime($record['check_out'])) : '--:--' ?></td>
                        <td>
                            <?php 
                            $statusClass = [
                                'present' => 'success',
                                'absent' => 'danger',
                                'late' => 'warning',
                                'leave' => 'info'
                            ];
                            ?>
                            <span class="badge bg-<?= $statusClass[$record['status']] ?>">
                                <?= $record['status'] === 'present' ? 'Có mặt' : 
                                   ($record['status'] === 'absent' ? 'Vắng mặt' : 
                                   ($record['status'] === 'late' ? 'Đi muộn' : 'Nghỉ phép')) ?>
                            </span>
                        </td>
                        <td><?= $record['notes'] ? htmlspecialchars($record['notes']) : '---' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
require_once '../../includes/footer.php';
?>